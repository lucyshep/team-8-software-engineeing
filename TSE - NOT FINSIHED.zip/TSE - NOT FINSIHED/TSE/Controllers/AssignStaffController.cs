﻿using Microsoft.AspNetCore.Mvc;
using TSE.Models;

namespace TSE.Controllers
{
    public class AssignStaffController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Assign(AssignStaff assignStaff)
        {
            return View("AssignSuccess", assignStaff);

        }
    }
}
