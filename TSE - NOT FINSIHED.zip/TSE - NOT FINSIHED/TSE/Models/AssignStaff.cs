﻿namespace TSE.Models
{
    public class AssignStaff
    {
        
        public int FieldNo { get; set; }

        public string StaffName { get; set; }
    }
}
