﻿using System;
using System.Data.SqlClient;
using TSE.Models;

namespace TSE.services
{
    public class AssignStaffService
    {
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog = LoginUsers; Integrated Security = True; Connect Timeout = 30; Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public bool findStaffMember (AssignStaff staffMemeber)
        {
            bool success  = false;
            string sqlStatement = "UPDATE Users SET AssignedTo = @AssignedTo WHERE Username = '@Username' ";
            
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@Username", System.Data.SqlDbType.NVarChar, 50).Value = staffMemeber.StaffName;
                command.Parameters.Add("@AssignedTo", System.Data.SqlDbType.Int).Value = staffMemeber.FieldNo;

                try
                {
                    //opens the connection 
                    connection.Open();
                    //reads the sql commands
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        success = true;
                    }
                    else if (rowsAffected == 0)
                    {
                        Console.WriteLine("ERROR");

                    }


                    //catch execption e 
                }
                catch (Exception e)
                {
                    //outputs the error 
                    Console.WriteLine(e.Message);
                    throw;
                }
            }

            return success;
        }
    }
}
