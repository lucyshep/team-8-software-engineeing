﻿Insert into dbo.users (Username, Password,AssignedTo) VALUES ('user1', '123', '9');
Insert into dbo.users (Username, Password,AssignedTo) VALUES ('testA', '123', '9');