﻿using Microsoft.AspNetCore.Mvc;
using TSE.services;

namespace TSE.Controllers
{
    public class OverviewController : Controller
    {
        //OverviewClass overview = new OverviewClass();


        public IActionResult Farm_Overview()
        {

            
            //overview.setField_2();
            //overview.setField_3();
            //overview.setField_4();
            //overview.setField_5();
            //overview.setField_6();
            //overview.setField_7();
            //overview.setField_8();
            //overview.setField_9();
            return View();
        }
    }
}
