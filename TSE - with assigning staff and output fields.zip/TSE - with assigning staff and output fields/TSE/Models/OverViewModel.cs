﻿namespace TSE.Models
{
    public class OverViewModel
    {
        public List<string> Field1 { get; set; }
        public List<string> Field2 { get; set; }
    }
}
