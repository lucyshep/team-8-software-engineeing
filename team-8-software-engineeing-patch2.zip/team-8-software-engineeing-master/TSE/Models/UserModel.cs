﻿namespace TSE.Models
{
    public class UserModel
    {
        //getter and setters for the Id, username and password 
        public int Id { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

    }
}
